<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="refresh" content="900">
    <title>VulnView</title>

    <meta name="description" content="Vulnerabilities">
    <meta name="author" content="R.Easton">
	
	<link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato|Oswald|Playfair+Display|Roboto|Abel|Jura|Orbitron|Poiret+One|Rajdhani|Tangerine|Tulpen+One" rel="stylesheet">
	<link href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	
  </head>
  <body>
	<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
				<span class="vulntitle">Patch & Security Vulnerabilities Dashboard</span>
		</div>
		<br/>
		
		<!-- if you don't want the buttons to show, comment the below div out -->
		<!--<div class="col-md-12">
			<a href="index.php" class="snip1434" target="_self"><i class='ion-ios-home-outline'></i> Home</a>
        		<a href="feed-admin.php" class="snip1434"><i class="ion-settings"></i> Feed Admin</a> 
			<a href="VulnView-180418.zip" class="snip1434"><i class="ion-stats-bars"></i> Download Latest Version</a>-->
		<!--</div>-->
		
		
	</div>
	<br>
